#coding=utf-8
import requests
from requests import RequestException
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import time
from io import BytesIO
from PIL import Image
from selenium.webdriver import ActionChains
from selenium.common.exceptions import TimeoutException
import random

class Crackxiaotest():
    def __init__(self):
        self.browser = webdriver.Firefox(executable_path='C:\Users\Administrator\Downloads\geckodriver-v0.24.0-win64\geckodriver.exe')
        self.url = 'https://www.xiaohongshu.com/web-login/captcha?redirectPath=http%3A%2F%2Fwww.xiaohongshu.com%2Fdiscovery%2Fitem%2F5d31402c000000002702add8'
        self.browser.get(self.url)
        time.sleep(3)
        self.wait = WebDriverWait(self.browser, 5)
    def __del__(self):
        self.browser.close()

    def is_success(self):
        test_str_n = 'ErrorTracker.js'
        url_n = 'http://www.xiaohongshu.com/page/topics/5d5515ec9916850001ab623b'
        response_n = requests.get(url_n, headers=headers)
        result = test_str_n in response_n.text.encode("utf-8")
        if result == True:
            return 1
        else:
            print u'验证码未验证成功'
            return 0

    def get_slider(self):
        #获取滑块对象
        slider = self.wait.until(EC.element_to_be_clickable((By.CLASS_NAME, 'shumei_captcha_slide_btn')))
        return slider
    def get_track(self, distance):
        # 移动轨迹
        track = []
        # 当前位移
        current = 0
        # 减速阀值
        mid = distance * 7 / 10
        # 计算间隔
        t = 0.15
        # 初速度
        v = 0
        while current < distance:
            if current < mid:
                # 加速度为正
                a = 4
            else:
                # 加速度为负
                a = -2
            # 初速度v0
            v0 = v
            # 当前速度 v = v0 + at
            v = v0 + a * t
            # 移动距离 x = v0t + 1/2*a*t*t
            move = v0 * t + 1 / 2 * a * t * t
            # 当前位移
            current += move
            # 加入轨迹
            track.append(round(move, 2))
        return track

    def move_to_gap(self, slider, tracks):
        # 点击并按住滑块
        ActionChains(self.browser).click_and_hold(slider).perform()
        # 移动
        for x in tracks:
            ActionChains(self.browser).move_by_offset(xoffset=x, yoffset=0).perform()
        time.sleep(0.1)
        # 释放滑块
        ActionChains(self.browser).release().perform()
    def for_move(self, x_temp):
        flag = 0
        gap = random.randint(16, 20) * 0 + x_temp
        #print('预估计缺口位置: ', gap)
            # self.is_try_again()
        slider = self.get_slider()
        track = self.get_track(gap)
        #print('滑动轨迹: ', track)
            # 拖动滑块
        self.move_to_gap(slider, track)
        time.sleep(3)

        if self.is_success():  #判断成功还没写
            flag = 1
        return flag
    def crack(self):
        #验证
        try:
            flag = 0
            while 1:
                flag = self.for_move(150)
                #成功的话 flag=1
                if flag == 1:
                    break
        except TimeoutException as e:
            self.crack()
        # 成功
        time.sleep(3)
        return 0

def get_page(url):
    try:
        headers = {
            'Referer': 'https://blog.csdn.net',  # 伪装成从CSDN博客搜索到的文章
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75 Safari/537.36',
            #'User-Agent': 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
            'Cookie':'xhsTrackerId=a4bfef76-0b0d-4370-c370-2303cfb40e8b; xhs_spid.5dde=3908282ec834fb9a.1566809323.8.1567001512.1566996180.18c09a8f-c465-4baf-a6ca-ee9e39a9cc48; extra_exp_ids=; xhs_spses.5dde=*',
        }
        a = 0
        while 1:
            a = a + 1
            test_str ='ErrorTracker.js'
            if(a < 3000):
                response = requests.get(url, headers=headers,allow_redirects=True)
                print response.status_code
                if response.status_code == 200:
                    result = test_str in response.text.encode("utf-8")
                    if result == True:
                        continue
                    else:
                        crack = Crackxiaotest()
                        crack.crack()
                        # 滑动验证码测试
                    #print response.text
                if response.status_code == 302:
                    crack = CrackGeetest()
                    crack.crack()

            if(a == 3000):
                print 'success!'
                break
    except RequestException:
        print u'请求出错'
        return None
def main():
    #url = 'http://www.xiaohongshu.com/page/topics/5d5515ec9916850001ab623b'  # 待刷浏览量博客的url
    url = 'https://www.xiaohongshu.com/web-login/captcha?redirectPath=http%3A%2F%2Fwww.xiaohongshu.com%2Fdiscovery%2Fitem%2F5d144cc000000000260383d2'
    get_page(url)
if __name__ == '__main__':
    main()



